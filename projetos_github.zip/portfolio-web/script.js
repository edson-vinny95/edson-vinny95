// Futuramente você pode adicionar animações ou interatividade aqui
console.log("Portfólio carregado com sucesso!");